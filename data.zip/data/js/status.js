import API from './api.js';

class StatusManager {
    constructor() {
        this.updateInterval = null;
        this.isUpdating = false;
    }

    // Status-Elemente aktualisieren
    async updateStatus() {
        if (this.isUpdating) return;
        this.isUpdating = true;

        try {
            const data = await API.getStatus();
            console.log('Status-Daten empfangen:', data);

            // Elemente aktualisieren
            const elements = {
                currentPosition: document.getElementById('current-position'),
                ntpTime: document.getElementById('ntp-time'),
                stepPosition: document.getElementById('step-position')
            };

            // Prüfen ob alle Elemente existieren
            for (const [key, element] of Object.entries(elements)) {
                if (!element) {
                    throw new Error(`Element ${key} nicht gefunden!`);
                }
            }

            // Werte aktualisieren
            elements.currentPosition.textContent = data.currentTime;
            elements.ntpTime.textContent = data.ntpTime;
            const percent = Math.round(data.currentPosition / 491520 * 100);
            elements.stepPosition.textContent = `${data.currentPosition} (${percent}%)`;

            console.log('Status-Anzeige aktualisiert');
        } catch (error) {
            console.error('Fehler beim Status-Update:', error);
        } finally {
            this.isUpdating = false;
        }
    }

    // Status-Updates starten
    start() {
        console.log('Starte Status-Updates...');
        // Ersten Update sofort durchführen
        this.updateStatus()
            .then(() => {
                console.log('Erster Status-Update erfolgreich');
                // Regelmäßige Updates starten
                this.updateInterval = setInterval(() => this.updateStatus(), 1000);
                console.log('Regelmäßige Updates aktiviert');
            })
            .catch(error => {
                console.error('Fehler beim ersten Status-Update:', error);
            });
    }

    // Status-Updates stoppen
    stop() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
            console.log('Status-Updates gestoppt');
        }
    }
}

export default new StatusManager(); 