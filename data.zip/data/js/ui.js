import API from './api.js';

class UI {
    constructor() {
        this.hourWheel = null;
        this.minuteWheel = null;
        this.isInitialized = false;
    }

    // UI initialisieren
    async init() {
        if (this.isInitialized) return;
        
        console.log('Initialisiere UI...');
        try {
            await this.initTimeWheels();
            this.isInitialized = true;
            console.log('UI erfolgreich initialisiert');
        } catch (error) {
            console.error('Fehler bei der UI-Initialisierung:', error);
            throw error;
        }
    }

    // Time Wheels initialisieren
    async initTimeWheels() {
        console.log('Initialisiere Time Wheels');
        
        // Time Wheels finden
        this.hourWheel = document.getElementById('hour-wheel');
        this.minuteWheel = document.getElementById('minute-wheel');
        
        if (!this.hourWheel || !this.minuteWheel) {
            throw new Error('Time Wheels nicht gefunden!');
        }

        // Time Wheels mit Werten füllen
        this.hourWheel.innerHTML = this.generateTimeItems(1, 12, 'hour');
        this.minuteWheel.innerHTML = this.generateTimeItems(0, 59, 'minute');

        // Event-Listener hinzufügen
        [this.hourWheel, this.minuteWheel].forEach(wheel => {
            this.setupWheelEvents(wheel);
        });

        // Initiale Position setzen
        this.scrollToTime(6, 30);
    }

    // Zeit-Elemente generieren
    generateTimeItems(start, end, type) {
        let items = '';
        for (let i = start; i <= end; i++) {
            const value = type === 'minute' && i < 10 ? `0${i}` : i;
            items += `<div class="time-item" data-value="${i}">${value}</div>`;
        }
        return items;
    }

    // Event-Listener für Time Wheels
    setupWheelEvents(wheel) {
        const itemHeight = 40;
        let touchStartY = 0;
        let scrollStartY = 0;
        let lastTouchY = 0;
        let scrollVelocity = 0;
        let lastTouchTime = 0;
        let isScrolling = false;

        // Mausrad-Events
        wheel.addEventListener('wheel', (e) => {
            e.preventDefault();
            const direction = e.deltaY > 0 ? 1 : -1;
            wheel.scrollTop += direction * itemHeight;
            this.updateSelectedItems(wheel);
            clearTimeout(wheel.scrollTimeout);
            wheel.scrollTimeout = setTimeout(() => this.snapToClosestItem(wheel), 50);
        }, { passive: false });

        // Touch-Events
        wheel.addEventListener('touchstart', (e) => {
            touchStartY = e.touches[0].clientY;
            lastTouchY = touchStartY;
            scrollStartY = wheel.scrollTop;
            lastTouchTime = Date.now();
            scrollVelocity = 0;
            isScrolling = true;
            wheel.style.scrollBehavior = 'auto';
        }, { passive: true });

        wheel.addEventListener('touchmove', (e) => {
            if (!isScrolling) return;
            const touch = e.touches[0];
            const currentY = touch.clientY;
            const deltaY = lastTouchY - currentY;
            const currentTime = Date.now();
            const deltaTime = currentTime - lastTouchTime;

            if (deltaTime > 0) {
                scrollVelocity = deltaY / deltaTime;
            }

            wheel.scrollTop = scrollStartY + (touchStartY - currentY);
            this.updateSelectedItems(wheel);

            lastTouchY = currentY;
            lastTouchTime = currentTime;
        }, { passive: true });

        wheel.addEventListener('touchend', () => {
            isScrolling = false;
            wheel.style.scrollBehavior = 'smooth';

            const momentum = Math.abs(scrollVelocity) > 0.5;
            if (momentum) {
                const direction = scrollVelocity > 0 ? 1 : -1;
                const speed = Math.min(Math.abs(scrollVelocity * 100), 300);
                wheel.scrollTop += direction * speed;
            }

            setTimeout(() => this.snapToClosestItem(wheel), momentum ? 300 : 0);
        });

        wheel.addEventListener('scroll', () => {
            if (!isScrolling) {
                this.updateSelectedItems(wheel);
            }
        });
    }

    // Ausgewählte Elemente aktualisieren
    updateSelectedItems(wheel) {
        const items = wheel.querySelectorAll('.time-item');
        const itemHeight = 40;
        const centerIndex = Math.round(wheel.scrollTop / itemHeight);
        
        items.forEach((item, index) => {
            if (index === centerIndex) {
                item.classList.add('selected');
            } else {
                item.classList.remove('selected');
            }
        });
    }

    // Zum nächsten Element snappen
    snapToClosestItem(wheel) {
        const itemHeight = 40;
        const scrollTop = wheel.scrollTop;
        const targetIndex = Math.round(scrollTop / itemHeight);
        const targetScroll = targetIndex * itemHeight;

        if (scrollTop !== targetScroll) {
            wheel.scrollTo({
                top: targetScroll,
                behavior: 'smooth'
            });
        }
    }

    // Zu bestimmter Zeit scrollen
    scrollToTime(hour, minute) {
        const itemHeight = 40;
        this.hourWheel.scrollTop = (hour - 1) * itemHeight;
        this.minuteWheel.scrollTop = minute * itemHeight;
        this.updateSelectedItems(this.hourWheel);
        this.updateSelectedItems(this.minuteWheel);
    }

    // Ausgewählte Zeit abrufen
    getSelectedTime() {
        const getSelectedValue = (wheel) => {
            const itemHeight = 40;
            const index = Math.round(wheel.scrollTop / itemHeight);
            const items = wheel.querySelectorAll('.time-item');
            return items[index] ? parseInt(items[index].getAttribute('data-value')) : 0;
        };

        return {
            hour: getSelectedValue(this.hourWheel),
            minute: getSelectedValue(this.minuteWheel)
        };
    }

    // Zeit setzen
    async setTime() {
        try {
            const time = this.getSelectedTime();
            console.log('Setze Zeit:', time);
            await API.setTime(time.hour, time.minute);
            console.log('Zeit erfolgreich gesetzt');
        } catch (error) {
            console.error('Fehler beim Setzen der Zeit:', error);
            alert('Fehler beim Setzen der Zeit');
        }
    }

    // Zeit anpassen
    async adjustTime(adjustment) {
        try {
            console.log('Passe Zeit an:', adjustment);
            await API.adjustTime(adjustment);
            console.log('Zeit erfolgreich angepasst');
        } catch (error) {
            console.error('Fehler bei der Zeitanpassung:', error);
            alert('Fehler bei der Zeitanpassung');
        }
    }

    // WLAN zurücksetzen
    async resetWiFi() {
        if (confirm('WLAN-Einstellungen wirklich zurücksetzen? Das Gerät startet danach neu im Access-Point-Modus.')) {
            try {
                await API.resetWiFi();
                alert('WLAN-Einstellungen wurden zurückgesetzt. Verbinden Sie sich mit dem WLAN-Hotspot der Uhr.');
            } catch (error) {
                console.error('Fehler beim WLAN-Reset:', error);
                alert('WLAN-Einstellungen wurden möglicherweise zurückgesetzt. Verbinden Sie sich mit dem WLAN-Hotspot der Uhr.');
            }
        }
    }

    // Gerät neustarten
    async restartDevice() {
        if (confirm('Gerät wirklich neu starten?')) {
            try {
                await API.restartDevice();
                alert('Das Gerät wird neu gestartet...');
                setTimeout(() => window.location.reload(), 5000);
            } catch (error) {
                console.error('Fehler beim Neustart:', error);
                alert('Das Gerät wird möglicherweise neu gestartet...');
                setTimeout(() => window.location.reload(), 5000);
            }
        }
    }

    // Firmware-Update starten
    startUpdate() {
        window.location.href = '/update';
    }
}

export default new UI(); 