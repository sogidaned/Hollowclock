import UI from './ui.js';
import StatusManager from './status.js';

class App {
    constructor() {
        this.ui = UI;
        this.statusManager = new StatusManager();
        this.initialized = false;
    }

    async init() {
        if (this.initialized) return;
        
        console.log('Initialisiere Anwendung...');
        try {
            // UI initialisieren
            await this.ui.init();
            
            // Status-Updates starten
            this.statusManager.start();
            
            // Event-Listener für Buttons
            this.setupEventListeners();
            
            this.initialized = true;
            console.log('Anwendung erfolgreich initialisiert');
        } catch (error) {
            console.error('Fehler bei der Initialisierung:', error);
            alert('Fehler beim Laden der Anwendung. Bitte Seite neu laden.');
        }
    }

    setupEventListeners() {
        // Zeit setzen
        document.getElementById('set-time-btn').addEventListener('click', () => {
            this.ui.setTime();
        });

        // Zeit anpassen
        const adjustButtons = {
            'adjust-minus-5-btn': -5,
            'adjust-minus-1-btn': -1,
            'adjust-plus-1-btn': 1,
            'adjust-plus-5-btn': 5
        };

        Object.entries(adjustButtons).forEach(([id, value]) => {
            document.getElementById(id).addEventListener('click', () => {
                this.ui.adjustTime(value);
            });
        });

        // System-Funktionen
        document.getElementById('reset-wifi-btn').addEventListener('click', () => {
            this.ui.resetWiFi();
        });

        document.getElementById('restart-btn').addEventListener('click', () => {
            this.ui.restartDevice();
        });

        document.getElementById('update-btn').addEventListener('click', () => {
            this.ui.startUpdate();
        });
    }
}

// Anwendung starten wenn DOM geladen ist
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM geladen, starte Anwendung...');
    const app = new App();
    app.init().catch(error => {
        console.error('Kritischer Fehler bei der Initialisierung:', error);
    });
}); 